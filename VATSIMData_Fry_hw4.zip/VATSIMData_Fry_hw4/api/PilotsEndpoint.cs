using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using Microsoft.EntityFrameworkCore;

using VatsimLibrary.VatsimClientV1;
using VatsimLibrary.VatsimDb;

namespace api
{
    
    public class PilotsEndpoint
    {
        public static async Task CallsignEndpoint(HttpContext context)
        {
            string responseText = null;
            string callsign = context.Request.RouteValues["callsign"] as string;
            switch((callsign ?? "").ToLower())
            {
                case "aal1":
                    responseText = "Callsign: AAL1";
                    break;
                default:
                    responseText = "Callsign: INVALID";
                    break;
            }

            if(callsign != null)
            {
                await context.Response.WriteAsync($"{responseText} is the callsign");
            }
            else
            {
                context.Response.StatusCode = StatusCodes.Status404NotFound;
            }
        }


        /* NOTE: All of these require that you first obtain a pilot and then search in Positions */
        

        public static async Task AltitudeEndpoint(HttpContext context)
        {
            string responseText = null;
            string pilotAltitude = context.Request.RouteValues["altitude"] as string;

            using(var db = new VatsimDbContext())
            {
                if (pilotAltitude != null)
                {
                    
                var _name = 
                    await
                    db.Positions
                    .Join(db.Pilots,
                        p=>p.Callsign,
                        n=>n.Callsign,
                        (p,n) => p)
                    .Where(n => n.Realname == (pilotAltitude ?? "").ToUpper()).ToListAsync();

                var _altitude =
                   await
                    db.Positions
                    .Join(db.Pilots,
                        p=>p.Callsign,
                        n=>n.Callsign,
                        (p,n) => p)
                    .Where(p => p.Altitude == (pilotAltitude ?? "").ToUpper()).ToListAsync();

                responseText = $"It appears that {_name} is flying at {_altitude} altitude";
                await context.Response.WriteAsync($"RESPONSE: {responseText}");

                }
                else {
                    context.Response.StatusCode = StatusCodes.Status404NotFound;
                }
            }

        }

        public static async Task GroundspeedEndpoint(HttpContext context)
        {
            string responseText = null;
            string pilotGroundspeed = context.Request.RouteValues["groundspeed"] as string;

            using(var db = new VatsimDbContext())
            {
                if (pilotGroundspeed != null)
                {
                    
                var _name = 
                    await
                    db.Positions
                    .Join(db.Pilots,
                        p=>p.Callsign,
                        n=>n.Callsign,
                        (p,n) => p)
                    .Where(n => n.Realname == (pilotGroundspeed ?? "").ToUpper()).ToListAsync();

                var _groundspeed =
                   await
                    db.Positions
                    .Join(db.Pilots,
                        p=>p.Callsign,
                        n=>n.Callsign,
                        (p,n) => p)
                    .Where(p => p.Groundspeed == (pilotGroundspeed ?? "").ToUpper()).ToListAsync();

                responseText = $"It appears that {_name} is moving at {_groundspeed} groundspeed";
                await context.Response.WriteAsync($"RESPONSE: {responseText}");

                }
                else {
                    context.Response.StatusCode = StatusCodes.Status404NotFound;
                }
            }

        }

        public static async Task LatitudeEndpoint(HttpContext context)        
        {
            string responseText = null;
            string pilotLatitude = context.Request.RouteValues["latitude"] as string;

            using(var db = new VatsimDbContext())
            {
                if (pilotLatitude != null)
                {
                    
                var _name = 
                    await
                    db.Positions
                    .Join(db.Pilots,
                        p=>p.Callsign,
                        n=>n.Callsign,
                        (p,n) => p)
                    .Where(n => n.Realname == (pilotLatitude ?? "").ToUpper()).ToListAsync();

                var _latitude =
                   await
                    db.Positions
                    .Join(db.Pilots,
                        p=>p.Callsign,
                        n=>n.Callsign,
                        (p,n) => p)
                    .Where(p => p.Latitude == (pilotLatitude ?? "").ToUpper()).ToListAsync();

                responseText = $"It appears that {_name} is at {_latitude} latitude";
                await context.Response.WriteAsync($"RESPONSE: {responseText}");

                }
                else {
                    context.Response.StatusCode = StatusCodes.Status404NotFound;
                }
            }
        }

        public static async Task LongitudeEndpoint(HttpContext context)
        {
            string responseText = null;
            string pilotLat = context.Request.RouteValues["longitude"] as string;

            using(var db = new VatsimDbContext())
            {
                if (pilotLat != null)
                {
                    
                var _name = 
                    await
                    db.Positions
                    .Join(db.Pilots,
                        p=>p.Callsign,
                        n=>n.Callsign,
                        (p,n) => p)
                    .Where(n => n.Realname == (pilotLat ?? "").ToUpper()).ToListAsync();

                var _long =
                   await
                    db.Positions
                    .Join(db.Pilots,
                        p=>p.Callsign,
                        n=>n.Callsign,
                        (p,n) => p)
                    .Where(p => p.Latitude == (pilotLat ?? "").ToUpper()).ToListAsync();

                responseText = $"It appears that {_name} is at {_long} longitude";
                await context.Response.WriteAsync($"RESPONSE: {responseText}");

                }
                else {
                    context.Response.StatusCode = StatusCodes.Status404NotFound;
                }
            }
        }
    }
}


    



